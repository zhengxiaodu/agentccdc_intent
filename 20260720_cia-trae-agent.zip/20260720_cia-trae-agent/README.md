# cia-trae-agent — OpenSandbox 沙箱能力建设交付工程

基于 agentscope 框架的 AI Agent 应用，集成 OpenSandbox（K8s 沙箱编排平台）实现高可用代码执行沙箱。

## 交付物目录

```
.
├── app/                          # 应用主代码
│   ├── config.py                 # 配置（含 WORKSPACE_BACKEND 开关）
│   ├── main.py                   # FastAPI 入口（双后端条件初始化）
│   └── services/
│       ├── opensandbox_workspace_manager.py  # OpenSandbox 工作区管理器（高可用）
│       ├── opensandbox_adapter.py            # SDK 工具适配层
│       ├── opensandbox_tool_bridge.py        # FunctionTool 桥接层
│       └── orchestrator_service.py           # 多智能体编排（双后端工具选择）
├── tests/opensandbox/            # OpenSandbox 能力验证测试（55 用例）
├── docs/                         # 方案文档
│   ├── opensandbox_capability_building_plan.md   # 主方案（架构+改造+高可用）
│   ├── opensandbox_cluster_deployment.md         # 集群部署手册
│   └── opensandbox_test_verification_guide.md    # 测试验证手册
├── deploy/opensandbox/           # K8s 部署 YAML（可直接 kubectl apply）
├── requirements.txt              # Python 依赖
├── pytest.ini                    # 测试配置
└── .env.example                  # 环境变量模板
```

## 快速开始

### 环境要求

- Python >= 3.12
- K8s 集群（已部署 OpenSandbox Server）或本地 Docker（开发模式）

### 安装依赖

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 配置

```bash
cp .env.example .env
# 编辑 .env，至少配置：
#   LLM_DEFAULT_API_KEY - 大模型 API Key
#   MYSQL_HOST / MYSQL_PASSWORD - 数据库连接
```

### 启动应用

```bash
# 默认使用 Docker 工作区（无需 K8s）
python -m uvicorn app.main:app --host 0.0.0.0 --port 7010

# 切换为 OpenSandbox 后端
WORKSPACE_BACKEND=opensandbox \
OPENSANDBOX_DOMAIN=localhost:9080 \
OPENSANDBOX_API_KEY=<your-key> \
OPENSANDBOX_POOL_SIZE=3 \
python -m uvicorn app.main:app --host 0.0.0.0 --port 7010
```

## 运行测试

```bash
# 全量测试（需要 OpenSandbox Server 可达）
OPENSANDBOX_API_KEY=<key> python -m pytest tests/opensandbox/ -v

# 预期结果: 60 passed in ~450s
```

分阶段执行和故障排查请参考 [测试验证手册](docs/opensandbox_test_verification_guide.md)。

## 切换 OpenSandbox 后端

| 步骤 | 操作 |
|---|---|
| 1 | 部署 OpenSandbox 集群（参考 [deploy/opensandbox/](deploy/opensandbox/)） |
| 2 | 配置 `.env`：`WORKSPACE_BACKEND=opensandbox` + 连接信息 |
| 3 | 重启应用 |
| 4 | 回滚：改回 `WORKSPACE_BACKEND=docker` 并重启 |

## 文档索引

| 文档 | 内容 |
|---|---|
| [能力建设方案](docs/opensandbox_capability_building_plan.md) | 架构设计、代码改造、高可用、验证结果、集成路径 |
| [集群部署手册](docs/opensandbox_cluster_deployment.md) | 镜像同步、K8s 部署、配置说明、运维指南 |
| [测试验证手册](docs/opensandbox_test_verification_guide.md) | 环境准备、测试执行、结果判读、FAQ |
| [部署 YAML](deploy/opensandbox/) | 可直接使用的 K8s 资源文件 |
