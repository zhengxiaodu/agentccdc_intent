import logging
import os
import uvicorn
import redis.asyncio as aioredis
import aiomysql
from contextlib import asynccontextmanager
from fastapi import FastAPI

# 开启 agentscope Docker 构建详细日志
logging.getLogger("agentscope.workspace._docker").setLevel(logging.DEBUG)

from app.config import (
    MODEL_CONFIG_PATH,
    REDIS_URL,
    MYSQL_HOST,
    MYSQL_PORT,
    MYSQL_USER,
    MYSQL_PASSWORD,
    MYSQL_DATABASE,
    WORKSPACE_BACKEND,
    WORKSPACE_BASE_IMAGE,
    WORKSPACE_BASEDIR,
    WORKSPACE_TTL,
    WORKSPACE_RETENTION_DAYS,
    WORKSPACE_CLEANUP_INTERVAL_HOURS,
    OPENSANDBOX_DOMAIN,
    OPENSANDBOX_API_KEY,
    OPENSANDBOX_PROTOCOL,
    OPENSANDBOX_USE_SERVER_PROXY,
    OPENSANDBOX_IMAGE,
    OPENSANDBOX_RESOURCE_CPU,
    OPENSANDBOX_RESOURCE_MEMORY,
    OPENSANDBOX_POOL_SIZE,
    OPENSANDBOX_POOL_REFILL,
)
from app.services.chat_service import load_model_config
from app.services.orchestrator_service import OrchestratorService
from app.services.workspace_manager import DockerWorkspaceManager
from app.services.workspace_cleanup_service import WorkspaceCleanupService
from app.dao.mysql_session_dao import SessionDAO
from app.dao.action_audit_dao import ActionAuditDAO
from app.dao.init_mysql import init_mysql_tables
from app.services.session_service import SessionService
from app.services.action_audit_service import ActionAuditService
from app.services.langfuse_service import LangfuseService
from app.routes import auth, chat, feedback, files, health, mng_proxy, sessions, upload, action_audit


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 初始化模型配置
    model_config = load_model_config(MODEL_CONFIG_PATH)
    app.state.model_config = model_config

    # ---- 工作区管理器（根据 WORKSPACE_BACKEND 选择后端） ----
    if WORKSPACE_BACKEND == "opensandbox":
        from datetime import timedelta
        from opensandbox.config import ConnectionConfig
        from app.services.opensandbox_workspace_manager import OpenSandboxWorkspaceManager

        osb_config = ConnectionConfig(
            domain=OPENSANDBOX_DOMAIN,
            protocol=OPENSANDBOX_PROTOCOL,
            api_key=OPENSANDBOX_API_KEY or None,
            use_server_proxy=OPENSANDBOX_USE_SERVER_PROXY,
            request_timeout=timedelta(seconds=120),
        )
        workspace_manager = OpenSandboxWorkspaceManager(
            connection_config=osb_config,
            base_image=OPENSANDBOX_IMAGE,
            basedir="/data/workspaces",
            ttl=WORKSPACE_TTL,
            resource={"cpu": OPENSANDBOX_RESOURCE_CPU, "memory": OPENSANDBOX_RESOURCE_MEMORY},
            ready_timeout=timedelta(seconds=120),
            pool_size=OPENSANDBOX_POOL_SIZE,
            pool_refill=OPENSANDBOX_POOL_REFILL,
        )
        print(
            f"Workspace manager initialized [opensandbox] "
            f"(domain={OPENSANDBOX_DOMAIN}, image={OPENSANDBOX_IMAGE}, ttl={WORKSPACE_TTL}, "
            f"pool_size={OPENSANDBOX_POOL_SIZE})"
        )
    else:
        workspace_manager = DockerWorkspaceManager(
            base_image=WORKSPACE_BASE_IMAGE,
            basedir=WORKSPACE_BASEDIR,
            ttl=WORKSPACE_TTL,
        )
        print(
            f"Workspace manager initialized [docker] "
            f"(image={WORKSPACE_BASE_IMAGE}, basedir={WORKSPACE_BASEDIR}, ttl={WORKSPACE_TTL})"
        )

    app.state.workspace_manager = workspace_manager
    app.state.workspace_backend = WORKSPACE_BACKEND
    await workspace_manager.start_sweeper()

    # ---- 工作区定时清理服务 ----
    cleanup_service = WorkspaceCleanupService(
        basedir=WORKSPACE_BASEDIR,
        retention_days=WORKSPACE_RETENTION_DAYS,
        interval_hours=WORKSPACE_CLEANUP_INTERVAL_HOURS,
    )
    cleanup_service.start()
    print(
        f"Workspace cleanup service started "
        f"(retention={WORKSPACE_RETENTION_DAYS}天, interval={WORKSPACE_CLEANUP_INTERVAL_HOURS}小时)"
    )

    # 初始化多智能体编排服务（加载智能体定义 + skill + 意图识别器）
    app.state.orchestrator_service = await OrchestratorService.create(
        model_config, workspace_manager
    )
    print("Orchestrator service initialized (multi-agent + multi-intent)")

    # ---- Redis（保留，用于其他需求） ----
    redis_client = aioredis.from_url(
        REDIS_URL,
        decode_responses=False,
    )
    app.state.redis_client = redis_client
    print(f"Redis client initialized ({REDIS_URL})")

    # ---- MySQL 连接池（会话持久化） ----
    mysql_pool = await aiomysql.create_pool(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        db=MYSQL_DATABASE,
        minsize=2,
        maxsize=10,
        autocommit=False,
    )
    await init_mysql_tables(mysql_pool)  # 自动建表
    app.state.mysql_pool = mysql_pool
    session_dao = SessionDAO(mysql_pool)
    app.state.session_dao = session_dao
    app.state.session_service = SessionService(session_dao)
    action_audit_dao = ActionAuditDAO(mysql_pool)
    app.state.action_audit_dao = action_audit_dao
    app.state.action_audit_service = ActionAuditService(action_audit_dao)
    print(
        f"Session service initialized "
        f"(MySQL: {MYSQL_USER}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE})"
    )

    # 初始化 Langfuse 追踪服务（非强依赖）
    app.state.langfuse_service = LangfuseService()
    if app.state.langfuse_service.enabled:
        print("Langfuse service initialized")
    else:
        print("Langfuse service disabled (credentials not configured)")

    yield

    # 关闭工作区管理器（停清扫 + 销毁全部容器）
    await workspace_manager.stop_sweeper()
    await workspace_manager.close_all()
    print("Workspace manager closed")

    cleanup_service.stop()
    print("Workspace cleanup service stopped")

    # 关闭 MySQL 连接池
    mysql_pool.close()
    await mysql_pool.wait_closed()
    print("MySQL pool closed")

    # 关闭 Redis 连接
    await redis_client.close()
    print("Redis connection closed")


app = FastAPI(lifespan=lifespan)

app.include_router(auth.router, tags=["auth"])
app.include_router(chat.router, tags=["chat"])
app.include_router(feedback.router, tags=["feedback"])
app.include_router(files.router, tags=["files"])
app.include_router(health.router, tags=["health"])
app.include_router(sessions.router, tags=["sessions"])
app.include_router(upload.router, tags=["upload"])
app.include_router(mng_proxy.router, tags=["mng"])
app.include_router(action_audit.router, tags=["action-audit"])

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=7010, reload=True)
