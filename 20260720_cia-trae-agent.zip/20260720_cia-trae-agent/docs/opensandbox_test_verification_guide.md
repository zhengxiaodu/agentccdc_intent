# OpenSandbox 测试验证手册

## 1. 环境准备

### 1.1 依赖安装

```bash
cd 20260720_cia-trae-agent

# 使用项目虚拟环境
python3 -m venv .venv
source .venv/bin/activate

# 安装依赖
pip install opensandbox>=0.1.13 opensandbox-code-interpreter>=0.1.0
pip install pytest pytest-asyncio
```

### 1.2 环境变量配置

```bash
# 必须配置
export OPENSANDBOX_API_KEY="<your-api-key>"

# 可选配置（有默认值）
export OPENSANDBOX_DOMAIN="localhost:9080"
export OPENSANDBOX_PROTOCOL="http"
export OPENSANDBOX_IMAGE="python:3.13-slim"
export OPENSANDBOX_USE_SERVER_PROXY="true"
```

### 1.3 网络连通性

```bash
# 建立 port-forward（本地开发环境）
kubectl port-forward svc/opensandbox-server 9080:80 -n opensandbox-system &

# 验证连通性
curl http://localhost:9080/health
# 预期输出: {"status":"healthy"}

# 验证 API Key
curl -H "Authorization: Bearer $OPENSANDBOX_API_KEY" http://localhost:9080/api/v1/sandboxes
# 预期输出: {"items":[],"total":0} 或沙箱列表
```

### 1.4 镜像预缓存（加速测试）

```bash
# 确认沙箱基础镜像已在节点上
docker pull python:3.13-slim

# Code Interpreter 镜像（国内源）
docker pull sandbox-registry.cn-zhangjiakou.cr.aliyuncs.com/opensandbox/code-interpreter:v1.1.0
docker tag sandbox-registry.cn-zhangjiakou.cr.aliyuncs.com/opensandbox/code-interpreter:v1.1.0 \
    opensandbox/code-interpreter:v1.1.0
```

---

## 2. 测试执行步骤

### 2.1 全量测试（推荐）

```bash
cd 20260720_cia-trae-agent
OPENSANDBOX_API_KEY=<key> .venv/bin/python3 -m pytest tests/opensandbox/ -v
```

预期结果：
```
60 passed in ~450s (0:07:30)
```

### 2.2 分阶段执行

**第一阶段：SDK 基础能力**

```bash
OPENSANDBOX_API_KEY=<key> .venv/bin/python3 -m pytest \
    tests/opensandbox/test_sandbox_lifecycle.py \
    tests/opensandbox/test_command_execution.py \
    tests/opensandbox/test_file_operations.py \
    tests/opensandbox/test_code_interpreter.py \
    -v
```

预期：24 passed（含 5 个 Code Interpreter）

**第二阶段：业务场景验证**

```bash
OPENSANDBOX_API_KEY=<key> .venv/bin/python3 -m pytest \
    tests/opensandbox/test_agent_tool_mapping.py \
    tests/opensandbox/test_skill_scenarios.py \
    tests/opensandbox/test_multi_tenant_isolation.py \
    tests/opensandbox/test_concurrency.py \
    -v
```

预期：18 passed

**第三阶段：集成测试**

```bash
OPENSANDBOX_API_KEY=<key> .venv/bin/python3 -m pytest \
    tests/opensandbox/test_integration_orchestrator.py \
    -v
```

预期：13 passed

### 2.3 单模块快速验证

```bash
# 仅验证沙箱能否创建（最快，~30s）
OPENSANDBOX_API_KEY=<key> .venv/bin/python3 -m pytest \
    tests/opensandbox/test_sandbox_lifecycle.py::TestSandboxLifecycle::test_create_and_destroy -v
```

---

## 3. 结果判读

### 3.1 正常输出

```
tests/opensandbox/test_sandbox_lifecycle.py::TestSandboxLifecycle::test_create_and_destroy PASSED
tests/opensandbox/test_sandbox_lifecycle.py::TestSandboxLifecycle::test_create_with_timeout PASSED
...
======================== 60 passed in 450.12s (0:07:30) =========================
```

### 3.2 常见失败及处理

| 失败信息 | 原因 | 处理 |
|---|---|---|
| `MISSING_API_KEY` | 未设置 OPENSANDBOX_API_KEY | 检查环境变量 |
| `INVALID_API_KEY` | API Key 错误 | 确认与 Server Secret 一致 |
| `504 GATEWAY_TIMEOUT` | 节点资源不足 | `kubectl describe nodes` 检查内存 |
| `health check timed out` | 无法直连 Pod | 确认 `use_server_proxy=True` |
| `ConnectionRefused localhost:9080` | port-forward 未运行 | 重新执行 kubectl port-forward |
| `ImagePullBackOff` | 镜像拉取失败 | 预拉取镜像到节点 |
| `OOMKilled` (Code Interpreter) | 内存不足 512Mi | 释放节点内存或扩容 |

---

## 4. Code Interpreter 专项

### 4.1 资源要求

- 最低内存：512Mi / 沙箱
- 镜像大小：~7GB（首次拉取耗时较长）
- 启动时间：~30s（含 Jupyter kernel 初始化）

### 4.2 运行条件

```bash
# 确认节点有足够可用内存（至少 1Gi 空闲）
kubectl describe nodes | grep -A 3 "Allocated resources"
# memory requests 应 < 80%

# 确认镜像已缓存
kubectl get events -n opensandbox | grep "code-interpreter"
# 应看到 "already present on machine"
```

### 4.3 测试内容

| 用例 | 验证点 |
|---|---|
| test_python_execution | Python 代码执行 + stdout 捕获 |
| test_state_persistence | 同一 context 内变量持久化 |
| test_stdout_capture | print 输出正确捕获 |
| test_streaming_code_output | 实时流式输出 |
| test_error_handling | 异常信息正确返回 |

---

## 5. 故障排查 FAQ

### Q1: 测试运行很慢（>10 分钟）

**原因**：每个测试函数创建独立沙箱，创建耗时 ~15-30s
**优化**：使用 `shared_sandbox` fixture（模块级复用）或减少测试范围

### Q2: 部分测试通过，部分 504 超时

**原因**：节点内存紧张，前几个沙箱占满后后续无法调度
**处理**：
```bash
# 清理残留沙箱
kubectl delete pods --all -n opensandbox
# 等待 10s 后重试
sleep 10
```

### Q3: port-forward 断开

**原因**：Server Pod 重启或网络波动
**处理**：
```bash
# 重新建立
kubectl port-forward svc/opensandbox-server 9080:80 -n opensandbox-system &
```

### Q4: 如何确认沙箱被正确清理

```bash
# 测试结束后应无残留 Pod
kubectl get pods -n opensandbox
# 预期: No resources found in opensandbox namespace.
```

### Q5: 如何在 CI/CD 中运行

```yaml
# GitLab CI 示例
opensandbox-tests:
  stage: test
  variables:
    OPENSANDBOX_DOMAIN: "opensandbox-server.opensandbox-system.svc:80"
    OPENSANDBOX_API_KEY: $OPENSANDBOX_API_KEY
    OPENSANDBOX_USE_SERVER_PROXY: "true"
  script:
    - pip install opensandbox opensandbox-code-interpreter pytest pytest-asyncio
    - pytest tests/opensandbox/ --tb=short -q
  timeout: 15m
```

---

## 6. 测试用例完整清单

| # | 文件 | 用例名 | 验证点 |
|---|---|---|---|
| 1 | test_sandbox_lifecycle | test_create_and_destroy | 创建/状态/销毁 |
| 2 | test_sandbox_lifecycle | test_create_with_timeout | 过期时间设置 |
| 3 | test_sandbox_lifecycle | test_create_with_env | 环境变量注入 |
| 4 | test_sandbox_lifecycle | test_create_with_resource_limits | 资源限制 |
| 5 | test_sandbox_lifecycle | test_get_info | 状态查询 |
| 6 | test_sandbox_lifecycle | test_renew | 续期 |
| 7 | test_command_execution | test_run_simple_command | 基础命令 |
| 8 | test_command_execution | test_run_python_script | Python 执行 |
| 9 | test_command_execution | test_run_command_with_stderr | stderr 捕获 |
| 10 | test_command_execution | test_run_command_exit_code | 退出码 |
| 11 | test_command_execution | test_streaming_output | 流式输出 |
| 12 | test_command_execution | test_run_pip_install | 包安装 |
| 13 | test_command_execution | test_run_long_command | 长命令 |
| 14 | test_file_operations | test_write_and_read_file | 文件读写 |
| 15 | test_file_operations | test_write_binary_file | 二进制文件 |
| 16 | test_file_operations | test_search_files | 文件搜索 |
| 17 | test_file_operations | test_delete_files | 文件删除 |
| 18 | test_file_operations | test_create_directory | 目录创建 |
| 19 | test_file_operations | test_file_in_working_dir | 工作目录 |
| 20 | test_code_interpreter | test_python_execution | CI Python 执行 |
| 21 | test_code_interpreter | test_state_persistence | CI 状态持久化 |
| 22 | test_code_interpreter | test_stdout_capture | CI stdout |
| 23 | test_code_interpreter | test_streaming_code_output | CI 流式 |
| 24 | test_code_interpreter | test_error_handling | CI 错误处理 |
| 25 | test_agent_tool_mapping | test_bash_tool | Bash 映射 |
| 26 | test_agent_tool_mapping | test_read_tool | Read 映射 |
| 27 | test_agent_tool_mapping | test_write_tool | Write 映射 |
| 28 | test_agent_tool_mapping | test_edit_tool | Edit 映射 |
| 29 | test_agent_tool_mapping | test_glob_tool | Glob 映射 |
| 30 | test_agent_tool_mapping | test_grep_tool | Grep 映射 |
| 31 | test_agent_tool_mapping | test_combined_workflow | 组合工作流 |
| 32 | test_skill_scenarios | test_chart_render_scenario | 图表渲染 |
| 33 | test_skill_scenarios | test_file_parse_scenario | 文件解析 |
| 34 | test_skill_scenarios | test_search_and_summarize | 搜索摘要 |
| 35 | test_skill_scenarios | test_skill_directory_mount | 技能注入 |
| 36 | test_multi_tenant_isolation | test_per_user_sandbox_isolation | 用户隔离 |
| 37 | test_multi_tenant_isolation | test_per_session_workdir_isolation | 会话隔离 |
| 38 | test_multi_tenant_isolation | test_sandbox_reuse_within_ttl | TTL 复用 |
| 39 | test_multi_tenant_isolation | test_sandbox_expiry_and_recreate | 过期重建 |
| 40 | test_concurrency | test_concurrent_sandbox_creation | 并发创建 |
| 41 | test_concurrency | test_concurrent_command_execution | 并发命令 |
| 42 | test_concurrency | test_concurrent_file_operations | 并发文件 |
| 43-55 | test_integration_orchestrator | (13 用例) | 管理器+适配层集成 |
| 56 | test_warm_pool | test_pool_warmup | 预热池创建 |
| 57 | test_warm_pool | test_acquire_from_pool | 池中分配 |
| 58 | test_warm_pool | test_pool_refill | 自动补充 |
| 59 | test_warm_pool | test_create_workspace_uses_pool | 集成验证 |
| 60 | test_warm_pool | test_pool_destroy_on_close | 关闭销毁 |
