"""OpenSandbox 测试公共 fixture。

环境变量：
  OPENSANDBOX_DOMAIN   - OpenSandbox server 地址（默认 localhost:9080）
  OPENSANDBOX_API_KEY  - API Key
  OPENSANDBOX_PROTOCOL - 协议（默认 http）
  OPENSANDBOX_IMAGE    - 沙箱基础镜像（默认 python:3.13-slim）
  OPENSANDBOX_USE_SERVER_PROXY - 是否通过 server 代理访问沙箱（默认 true）
"""
import os
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.config import ConnectionConfig


# ---- 全局配置 ----
OPENSANDBOX_DOMAIN = os.getenv("OPENSANDBOX_DOMAIN", "localhost:9080")
OPENSANDBOX_API_KEY = os.getenv("OPENSANDBOX_API_KEY", "")
OPENSANDBOX_PROTOCOL = os.getenv("OPENSANDBOX_PROTOCOL", "http")
OPENSANDBOX_IMAGE = os.getenv("OPENSANDBOX_IMAGE", "python:3.13-slim")
OPENSANDBOX_USE_SERVER_PROXY = os.getenv("OPENSANDBOX_USE_SERVER_PROXY", "true").lower() == "true"
# 沙箱默认资源配置（本地 k8s 节点内存有限，使用较小值）
DEFAULT_RESOURCE = {"cpu": "100m", "memory": "128Mi"}
CODE_INTERPRETER_IMAGE = os.getenv(
    "OPENSANDBOX_CI_IMAGE", "opensandbox/code-interpreter:v1.1.0"
)


@pytest.fixture(scope="session")
def connection_config() -> ConnectionConfig:
    """会话级 ConnectionConfig fixture。"""
    kwargs = {
        "domain": OPENSANDBOX_DOMAIN,
        "protocol": OPENSANDBOX_PROTOCOL,
        "request_timeout": timedelta(seconds=120),
        "use_server_proxy": OPENSANDBOX_USE_SERVER_PROXY,
    }
    if OPENSANDBOX_API_KEY:
        kwargs["api_key"] = OPENSANDBOX_API_KEY
    return ConnectionConfig(**kwargs)


@pytest_asyncio.fixture
async def sandbox(connection_config):
    """函数级沙箱 fixture：每个测试函数独立创建/销毁。"""
    sbx = await Sandbox.create(
        OPENSANDBOX_IMAGE,
        connection_config=connection_config,
        timeout=timedelta(minutes=10),
        resource=DEFAULT_RESOURCE,
        ready_timeout=timedelta(seconds=120),
    )
    yield sbx
    try:
        await sbx.destroy()
    except Exception:
        pass


@pytest_asyncio.fixture(scope="module")
async def shared_sandbox(connection_config):
    """模块级共享沙箱：同一模块内测试复用，减少创建开销。"""
    sbx = await Sandbox.create(
        OPENSANDBOX_IMAGE,
        connection_config=connection_config,
        timeout=timedelta(minutes=30),
        resource=DEFAULT_RESOURCE,
        ready_timeout=timedelta(seconds=120),
    )
    yield sbx
    try:
        await sbx.destroy()
    except Exception:
        pass
