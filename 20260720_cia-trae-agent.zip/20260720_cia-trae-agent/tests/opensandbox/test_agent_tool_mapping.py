"""第二阶段：Agent 工具映射测试。

验证 OpenSandbox 能否替代 agentscope 的 6 个内置工具：
Bash, Read, Write, Edit, Glob, Grep
"""
import pytest
import pytest_asyncio

from opensandbox.models.filesystem import WriteEntry, SearchEntry


pytestmark = pytest.mark.asyncio


class TestAgentToolMapping:
    """模拟 agentscope 工具在 OpenSandbox 上的等价实现。"""

    async def test_bash_tool(self, sandbox):
        """Bash() 工具 -> sandbox.commands.run()"""
        result = await sandbox.commands.run("ls -la /tmp")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert len(stdout_text) > 0
        assert result.exit_code == 0

    async def test_read_tool(self, sandbox):
        """Read() 工具 -> sandbox.files.read_file()"""
        # 先写入测试文件
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/read_test.txt", data="line1\nline2\nline3", mode=644)
        ])
        content = await sandbox.files.read_file("/tmp/read_test.txt")
        assert "line1" in content
        assert "line3" in content

    async def test_write_tool(self, sandbox):
        """Write() 工具 -> sandbox.files.write_files()"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/write_test.py", data="print('hello')\n", mode=644)
        ])
        # 验证文件可执行
        result = await sandbox.commands.run("python3 /tmp/write_test.py")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "hello" in stdout_text

    async def test_edit_tool(self, sandbox):
        """Edit() 工具 -> 读取 + 修改 + 写回"""
        original = "def foo():\n    return 1\n"
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/edit_test.py", data=original, mode=644)
        ])
        # 读取
        content = await sandbox.files.read_file("/tmp/edit_test.py")
        # 修改
        modified = content.replace("return 1", "return 42")
        # 写回
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/edit_test.py", data=modified, mode=644)
        ])
        # 验证修改生效
        result = await sandbox.commands.run("cd /tmp && python3 -c 'from edit_test import foo; print(foo())'")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "42" in stdout_text

    async def test_glob_tool(self, sandbox):
        """Glob() 工具 -> sandbox.files.search()"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/glob_dir/a.py", data="# a", mode=644),
            WriteEntry(path="/tmp/glob_dir/b.py", data="# b", mode=644),
            WriteEntry(path="/tmp/glob_dir/c.txt", data="c", mode=644),
        ])
        results = await sandbox.files.search(
            SearchEntry(path="/tmp/glob_dir", pattern="*.py")
        )
        py_files = [f.path for f in results]
        assert len(py_files) >= 2

    async def test_grep_tool(self, sandbox):
        """Grep() 工具 -> sandbox.commands.run("grep ...")"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/grep_dir/file1.py", data="import os\nimport sys\n", mode=644),
            WriteEntry(path="/tmp/grep_dir/file2.py", data="import json\n", mode=644),
        ])
        result = await sandbox.commands.run("grep -r 'import os' /tmp/grep_dir/")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "file1.py" in stdout_text
        assert "file2.py" not in stdout_text
