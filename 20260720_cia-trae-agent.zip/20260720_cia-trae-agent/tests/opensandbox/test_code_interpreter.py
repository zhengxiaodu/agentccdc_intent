"""第一阶段：Code Interpreter 测试。

注意：需要 opensandbox/code-interpreter 镜像可用。
若镜像不可用，这些测试将被跳过。
"""
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.config import ConnectionConfig
from opensandbox.models.execd import ExecutionHandlers

try:
    from code_interpreter import CodeInterpreter, SupportedLanguage
    HAS_CI = True
except ImportError:
    HAS_CI = False

from .conftest import CODE_INTERPRETER_IMAGE, DEFAULT_RESOURCE


pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture
async def ci_sandbox(connection_config):
    """创建 Code Interpreter 专用沙箱。"""
    sbx = await Sandbox.create(
        CODE_INTERPRETER_IMAGE,
        connection_config=connection_config,
        entrypoint=["/opt/code-interpreter/code-interpreter.sh"],
        timeout=timedelta(minutes=10),
        resource={"cpu": "500m", "memory": "512Mi"},
        ready_timeout=timedelta(seconds=120),
    )
    yield sbx
    try:
        await sbx.destroy()
    except Exception:
        pass


@pytest.mark.skipif(not HAS_CI, reason="opensandbox-code-interpreter not installed")
class TestCodeInterpreter:
    """代码解释器功能验证。"""

    async def test_python_execution(self, ci_sandbox):
        """执行 Python 代码，验证 result 和 stdout。"""
        interpreter = await CodeInterpreter.create(sandbox=ci_sandbox)
        result = await interpreter.codes.run(
            "import sys\nprint(sys.version)\nresult = 2 + 2\nresult",
            language=SupportedLanguage.PYTHON,
        )
        assert result.result and result.result[0].text == "4"

    async def test_state_persistence(self, ci_sandbox):
        """同一 context 内变量持久化。"""
        interpreter = await CodeInterpreter.create(sandbox=ci_sandbox)
        ctx = await interpreter.codes.create_context(SupportedLanguage.PYTHON)
        await interpreter.codes.run("x = 42", context=ctx)
        # Jupyter 只对最后一个表达式产生 display output，赋值语句不产生
        result = await interpreter.codes.run("x", context=ctx)
        assert result.result and result.result[0].text == "42"

    async def test_stdout_capture(self, ci_sandbox):
        """验证 print 输出被捕获到 logs.stdout。"""
        interpreter = await CodeInterpreter.create(sandbox=ci_sandbox)
        result = await interpreter.codes.run(
            "print('hello_from_python')",
            language=SupportedLanguage.PYTHON,
        )
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "hello_from_python" in stdout_text

    async def test_streaming_code_output(self, ci_sandbox):
        """使用 handlers 实时捕获代码执行输出。"""
        collected = []

        async def on_stdout(msg):
            collected.append(msg.text)

        handlers = ExecutionHandlers(on_stdout=on_stdout)
        interpreter = await CodeInterpreter.create(sandbox=ci_sandbox)
        await interpreter.codes.run(
            "import time\nfor i in range(3):\n    print(i)\n    time.sleep(0.2)",
            language=SupportedLanguage.PYTHON,
            handlers=handlers,
        )
        combined = "".join(collected)
        assert "0" in combined
        assert "2" in combined

    async def test_error_handling(self, ci_sandbox):
        """执行会报错的代码，验证错误信息捕获。"""
        interpreter = await CodeInterpreter.create(sandbox=ci_sandbox)
        result = await interpreter.codes.run(
            "raise ValueError('test_error')",
            language=SupportedLanguage.PYTHON,
        )
        # Jupyter 错误信息在 result.error 或 stderr 中
        error_text = ""
        if result.error:
            error_text = str(getattr(result.error, 'name', '')) + str(getattr(result.error, 'value', '')) + str(getattr(result.error, 'traceback', ''))
        stderr_text = "".join(m.text for m in result.logs.stderr)
        combined = error_text + stderr_text
        assert "test_error" in combined or "ValueError" in combined
