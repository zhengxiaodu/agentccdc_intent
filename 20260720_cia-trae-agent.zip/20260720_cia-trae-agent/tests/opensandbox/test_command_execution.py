"""第一阶段：命令执行测试。"""
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.models.execd import ExecutionHandlers


pytestmark = pytest.mark.asyncio


class TestCommandExecution:
    """沙箱内命令执行能力验证。"""

    async def test_run_simple_command(self, sandbox):
        """执行 echo 命令，验证 stdout。"""
        result = await sandbox.commands.run("echo hello")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "hello" in stdout_text

    async def test_run_python_script(self, sandbox):
        """在沙箱内执行 Python 脚本。"""
        result = await sandbox.commands.run("python3 -c 'print(1+1)'")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "2" in stdout_text

    async def test_run_command_with_stderr(self, sandbox):
        """验证 stderr 输出捕获。"""
        result = await sandbox.commands.run("echo error_msg >&2")
        stderr_text = "".join(m.text for m in result.logs.stderr)
        assert "error_msg" in stderr_text

    async def test_run_command_exit_code(self, sandbox):
        """验证非零退出码。"""
        result = await sandbox.commands.run("exit 1")
        assert result.exit_code != 0

    async def test_streaming_output(self, sandbox):
        """使用 ExecutionHandlers 实时捕获 stdout。"""
        collected = []

        async def on_stdout(msg):
            collected.append(msg.text)

        handlers = ExecutionHandlers(on_stdout=on_stdout)
        await sandbox.commands.run(
            "for i in 1 2 3; do echo \"count_$i\"; done",
            handlers=handlers,
        )
        combined = "".join(collected)
        assert "count_1" in combined
        assert "count_3" in combined

    async def test_run_pip_install(self, sandbox):
        """在沙箱内安装 Python 包。"""
        result = await sandbox.commands.run("pip install requests -q")
        # 验证安装成功
        verify = await sandbox.commands.run("python3 -c 'import requests; print(requests.__version__)'")
        stdout_text = "".join(m.text for m in verify.logs.stdout)
        assert len(stdout_text.strip()) > 0

    async def test_run_long_command(self, sandbox):
        """执行耗时命令，验证正常完成。"""
        result = await sandbox.commands.run("sleep 3 && echo done")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "done" in stdout_text

    async def test_run_multiline_script(self, sandbox):
        """执行多行 shell 脚本。"""
        script = """echo start
for i in $(seq 1 5); do
  echo "line_$i"
done
echo end"""
        result = await sandbox.commands.run(script)
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "start" in stdout_text
        assert "line_3" in stdout_text
        assert "end" in stdout_text
