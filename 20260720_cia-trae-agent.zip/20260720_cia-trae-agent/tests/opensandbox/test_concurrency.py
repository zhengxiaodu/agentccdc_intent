"""第二阶段：并发安全测试。"""
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.models.filesystem import WriteEntry

from .conftest import OPENSANDBOX_IMAGE, DEFAULT_RESOURCE


pytestmark = pytest.mark.asyncio


class TestConcurrency:
    """并发场景下的沙箱稳定性验证。"""

    async def test_concurrent_sandbox_creation(self, connection_config):
        """并发创建多个沙箱，验证全部成功。"""
        async def create_one(i):
            sbx = await Sandbox.create(
                OPENSANDBOX_IMAGE, connection_config=connection_config,
                timeout=timedelta(minutes=5),
                resource=DEFAULT_RESOURCE,
                ready_timeout=timedelta(seconds=120),
            )
            return sbx

        sandboxes = await asyncio.gather(*[create_one(i) for i in range(2)])
        try:
            ids = set()
            for sbx in sandboxes:
                info = await sbx.get_info()
                assert info.status.state.lower() == "running"
                ids.add(sbx.id)
            # 所有沙箱 ID 唯一
            assert len(ids) == 2
        finally:
            for sbx in sandboxes:
                try:
                    await sbx.destroy()
                except Exception:
                    pass

    async def test_concurrent_command_execution(self, sandbox):
        """同一沙箱内并发执行多条命令。"""
        async def run_cmd(i):
            result = await sandbox.commands.run(f"echo result_{i}")
            return "".join(m.text for m in result.logs.stdout)

        results = await asyncio.gather(*[run_cmd(i) for i in range(5)])
        for i, r in enumerate(results):
            assert f"result_{i}" in r

    async def test_concurrent_file_operations(self, sandbox):
        """并发读写不同文件，验证无冲突。"""
        async def write_and_read(i):
            path = f"/tmp/concurrent/file_{i}.txt"
            await sandbox.files.write_files([
                WriteEntry(path=path, data=f"content_{i}", mode=644)
            ])
            content = await sandbox.files.read_file(path)
            return content

        # 先创建目录
        await sandbox.commands.run("mkdir -p /tmp/concurrent")
        results = await asyncio.gather(*[write_and_read(i) for i in range(5)])
        for i, r in enumerate(results):
            assert f"content_{i}" in r

    async def test_concurrent_mixed_operations(self, sandbox):
        """并发混合操作：命令执行 + 文件写入。"""
        async def cmd_task():
            result = await sandbox.commands.run("echo cmd_done")
            return "".join(m.text for m in result.logs.stdout)

        async def file_task():
            await sandbox.files.write_files([
                WriteEntry(path="/tmp/mixed.txt", data="file_done", mode=644)
            ])
            return await sandbox.files.read_file("/tmp/mixed.txt")

        r_cmd, r_file = await asyncio.gather(cmd_task(), file_task())
        assert "cmd_done" in r_cmd
        assert "file_done" in r_file
