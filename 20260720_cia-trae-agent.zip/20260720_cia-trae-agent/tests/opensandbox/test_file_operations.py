"""第一阶段：文件操作测试。"""
import base64
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.models.filesystem import WriteEntry, SearchEntry


pytestmark = pytest.mark.asyncio


class TestFileOperations:
    """沙箱内文件读写、搜索、删除。"""

    async def test_write_and_read_file(self, sandbox):
        """写入文件后读取，验证内容一致。"""
        content = "Hello OpenSandbox! 你好世界"
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/test_hello.txt", data=content, mode=644)
        ])
        result = await sandbox.files.read_file("/tmp/test_hello.txt")
        assert content in result

    async def test_write_multiple_files(self, sandbox):
        """批量写入多个文件。"""
        entries = [
            WriteEntry(path="/tmp/multi/a.txt", data="file_a", mode=644),
            WriteEntry(path="/tmp/multi/b.txt", data="file_b", mode=644),
        ]
        await sandbox.files.write_files(entries)
        a = await sandbox.files.read_file("/tmp/multi/a.txt")
        b = await sandbox.files.read_file("/tmp/multi/b.txt")
        assert "file_a" in a
        assert "file_b" in b

    async def test_search_files(self, sandbox):
        """写入多个文件后按 pattern 搜索。"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/search/data_1.csv", data="a,b", mode=644),
            WriteEntry(path="/tmp/search/data_2.csv", data="c,d", mode=644),
            WriteEntry(path="/tmp/search/readme.txt", data="hi", mode=644),
        ])
        results = await sandbox.files.search(
            SearchEntry(path="/tmp/search", pattern="*.csv")
        )
        paths = [f.path for f in results]
        assert any("data_1.csv" in p for p in paths)
        assert any("data_2.csv" in p for p in paths)

    async def test_delete_files(self, sandbox):
        """写入后删除，验证文件不存在。"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/to_delete.txt", data="bye", mode=644)
        ])
        await sandbox.files.delete_files(["/tmp/to_delete.txt"])
        # 通过命令验证文件已删除
        result = await sandbox.commands.run("test -f /tmp/to_delete.txt && echo exists || echo gone")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "gone" in stdout_text

    async def test_create_directory(self, sandbox):
        """通过命令创建目录并验证。"""
        await sandbox.commands.run("mkdir -p /tmp/mydir/subdir")
        result = await sandbox.commands.run("test -d /tmp/mydir/subdir && echo ok")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "ok" in stdout_text

    async def test_file_in_session_workdir(self, sandbox):
        """模拟 cia-trae-agent 的 session 工作目录模式。"""
        session_dir = "/data/workspaces/session-001"
        await sandbox.commands.run(f"mkdir -p {session_dir}/data")
        await sandbox.files.write_files([
            WriteEntry(path=f"{session_dir}/data/upload.txt", data="uploaded content", mode=644)
        ])
        content = await sandbox.files.read_file(f"{session_dir}/data/upload.txt")
        assert "uploaded content" in content

    async def test_large_file_write(self, sandbox):
        """写入较大文件（100KB），验证完整性。"""
        large_data = "x" * 102400
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/large.txt", data=large_data, mode=644)
        ])
        result = await sandbox.commands.run("wc -c /tmp/large.txt")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "102400" in stdout_text
