"""第三阶段：集成测试。

验证 OpenSandboxWorkspaceManager + 适配层的完整流程。
"""
import asyncio
import os
import sys
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.config import ConnectionConfig
from opensandbox.models.filesystem import WriteEntry

from .conftest import OPENSANDBOX_DOMAIN, OPENSANDBOX_API_KEY, OPENSANDBOX_PROTOCOL, OPENSANDBOX_IMAGE

# 将项目根目录加入 path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from app.services.opensandbox_workspace_manager import OpenSandboxWorkspaceManager
from app.services.opensandbox_adapter import OpenSandboxToolAdapter


pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture
async def ws_manager(connection_config):
    """创建 OpenSandboxWorkspaceManager 实例。"""
    mgr = OpenSandboxWorkspaceManager(
        connection_config=connection_config,
        base_image=OPENSANDBOX_IMAGE,
        basedir="/data/workspaces",
        ttl=600,  # 10分钟
    )
    await mgr.start_sweeper()
    yield mgr
    await mgr.stop_sweeper()
    await mgr.close_all()


class TestWorkspaceManagerIntegration:
    """工作区管理器集成测试。"""

    async def test_create_and_reuse(self, ws_manager):
        """验证创建/复用逻辑。"""
        sbx1 = await ws_manager.create_workspace("user-001", "session-a", [])
        assert sbx1 is not None
        # 同一用户复用
        sbx2 = await ws_manager.create_workspace("user-001", "session-b", [])
        assert sbx2.id == sbx1.id

    async def test_different_users_get_different_sandboxes(self, ws_manager):
        """不同用户分配不同沙箱。"""
        sbx_a = await ws_manager.create_workspace("user-a", "s1", [])
        sbx_b = await ws_manager.create_workspace("user-b", "s1", [])
        assert sbx_a.id != sbx_b.id

    async def test_get_workspace(self, ws_manager):
        """验证 get_workspace 获取已有沙箱。"""
        await ws_manager.create_workspace("user-x", "s1", [])
        sbx = await ws_manager.get_workspace("user-x", "s2")
        assert sbx is not None

    async def test_get_workspace_not_found(self, ws_manager):
        """不存在的用户返回 None。"""
        result = await ws_manager.get_workspace("nonexistent", "s1")
        assert result is None

    async def test_close_workspace(self, ws_manager):
        """关闭后 get 返回 None。"""
        await ws_manager.create_workspace("user-close", "s1", [])
        await ws_manager.close("user-user-close")
        result = await ws_manager.get_workspace("user-close", "s1")
        assert result is None


class TestAdapterIntegration:
    """适配层集成测试。"""

    async def test_bash_via_adapter(self, sandbox):
        """通过适配层执行命令。"""
        adapter = OpenSandboxToolAdapter(sandbox, workdir="/tmp")
        result = await adapter.bash("echo adapter_test")
        assert "adapter_test" in result["stdout"]
        assert result["exit_code"] == 0

    async def test_read_write_via_adapter(self, sandbox):
        """通过适配层读写文件。"""
        adapter = OpenSandboxToolAdapter(sandbox, workdir="/tmp")
        await adapter.write("/tmp/adapter_rw.txt", "hello adapter")
        content = await adapter.read("/tmp/adapter_rw.txt")
        assert "hello adapter" in content

    async def test_edit_via_adapter(self, sandbox):
        """通过适配层编辑文件。"""
        adapter = OpenSandboxToolAdapter(sandbox, workdir="/tmp")
        await adapter.write("/tmp/adapter_edit.txt", "foo bar baz")
        await adapter.edit("/tmp/adapter_edit.txt", "bar", "qux")
        content = await adapter.read("/tmp/adapter_edit.txt")
        assert "qux" in content
        assert "bar" not in content

    async def test_glob_via_adapter(self, sandbox):
        """通过适配层搜索文件。"""
        adapter = OpenSandboxToolAdapter(sandbox, workdir="/tmp")
        await adapter.ensure_dir("/tmp/adapter_glob")
        await adapter.write("/tmp/adapter_glob/x.py", "# x")
        await adapter.write("/tmp/adapter_glob/y.py", "# y")
        await adapter.write("/tmp/adapter_glob/z.txt", "z")
        results = await adapter.glob("*.py", "/tmp/adapter_glob")
        assert len(results) >= 2

    async def test_grep_via_adapter(self, sandbox):
        """通过适配层 grep 搜索。"""
        adapter = OpenSandboxToolAdapter(sandbox, workdir="/tmp")
        await adapter.ensure_dir("/tmp/adapter_grep")
        await adapter.write("/tmp/adapter_grep/a.py", "import os")
        await adapter.write("/tmp/adapter_grep/b.py", "import sys")
        result = await adapter.grep("import os", "/tmp/adapter_grep")
        assert "a.py" in result

    async def test_full_workflow(self, ws_manager):
        """完整工作流：创建工作区 -> 适配层操作 -> 清理。"""
        sbx = await ws_manager.create_workspace("user-flow", "session-flow", [])
        adapter = OpenSandboxToolAdapter(sbx, workdir="/data/workspaces/session-flow")
        # 确保工作目录
        await adapter.ensure_dir(adapter.workdir)
        # 写入文件
        await adapter.write(f"{adapter.workdir}/result.json", '{"status": "ok"}')
        # 执行命令验证
        result = await adapter.bash(f"cat {adapter.workdir}/result.json")
        assert "ok" in result["stdout"]
