"""第二阶段：多租户隔离测试。

模拟 DockerWorkspaceManager 的隔离策略：
- 按 user_id 分配独立沙箱
- 按 session_id 隔离工作目录
- TTL 复用与过期重建
"""
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.models.filesystem import WriteEntry

from .conftest import OPENSANDBOX_IMAGE, DEFAULT_RESOURCE


pytestmark = pytest.mark.asyncio


class TestMultiTenantIsolation:
    """多用户/多会话隔离验证。"""

    async def test_per_user_sandbox_isolation(self, connection_config):
        """为两个 user 分别创建沙箱，验证文件系统互不可见。"""
        sbx_a = await Sandbox.create(
            OPENSANDBOX_IMAGE, connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        sbx_b = await Sandbox.create(
            OPENSANDBOX_IMAGE, connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            # user_a 写入文件
            await sbx_a.files.write_files([
                WriteEntry(path="/tmp/secret_a.txt", data="user_a_secret", mode=644)
            ])
            # user_b 写入文件
            await sbx_b.files.write_files([
                WriteEntry(path="/tmp/secret_b.txt", data="user_b_secret", mode=644)
            ])
            # user_b 不能看到 user_a 的文件
            result = await sbx_b.commands.run("test -f /tmp/secret_a.txt && echo visible || echo isolated")
            stdout_text = "".join(m.text for m in result.logs.stdout)
            assert "isolated" in stdout_text
            # user_a 不能看到 user_b 的文件
            result = await sbx_a.commands.run("test -f /tmp/secret_b.txt && echo visible || echo isolated")
            stdout_text = "".join(m.text for m in result.logs.stdout)
            assert "isolated" in stdout_text
        finally:
            await sbx_a.destroy()
            await sbx_b.destroy()

    async def test_per_session_workdir_isolation(self, sandbox):
        """同一沙箱内按 session_id 创建子目录，验证工作目录隔离。"""
        # 模拟两个 session 的工作目录
        await sandbox.commands.run("mkdir -p /data/ws/session-001 /data/ws/session-002")
        await sandbox.files.write_files([
            WriteEntry(path="/data/ws/session-001/output.txt", data="s1_data", mode=644),
            WriteEntry(path="/data/ws/session-002/output.txt", data="s2_data", mode=644),
        ])
        # 验证各 session 目录独立
        r1 = await sandbox.files.read_file("/data/ws/session-001/output.txt")
        r2 = await sandbox.files.read_file("/data/ws/session-002/output.txt")
        assert "s1_data" in r1
        assert "s2_data" in r2
        assert "s2_data" not in r1

    async def test_sandbox_reuse_within_ttl(self, connection_config):
        """模拟同一用户多次请求复用同一沙箱。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE, connection_config=connection_config,
            timeout=timedelta(minutes=10),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            sandbox_id = sbx.id
            # 第一次操作：写入文件
            await sbx.files.write_files([
                WriteEntry(path="/tmp/state.txt", data="round_1", mode=644)
            ])
            # 第二次操作：验证状态保留（模拟复用）
            content = await sbx.files.read_file("/tmp/state.txt")
            assert "round_1" in content
            # 第三次操作：追加内容
            await sbx.files.write_files([
                WriteEntry(path="/tmp/state.txt", data="round_2", mode=644)
            ])
            content = await sbx.files.read_file("/tmp/state.txt")
            assert "round_2" in content
            # 沙箱 ID 未变
            assert sbx.id == sandbox_id
        finally:
            await sbx.destroy()

    async def test_sandbox_expiry_and_recreate(self, connection_config):
        """创建短 TTL 沙箱，验证过期后需重建。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE, connection_config=connection_config,
            timeout=timedelta(seconds=60),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        sandbox_id = sbx.id
        # 验证沙箱存在
        info = await sbx.get_info()
        assert info.status.state.lower() == "running"
        # 销毁模拟过期
        await sbx.destroy()
        # 重建新沙箱
        sbx_new = await Sandbox.create(
            OPENSANDBOX_IMAGE, connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            assert sbx_new.id != sandbox_id  # 新沙箱 ID 不同
            info_new = await sbx_new.get_info()
            assert info_new.status.state.lower() == "running"
        finally:
            await sbx_new.destroy()
