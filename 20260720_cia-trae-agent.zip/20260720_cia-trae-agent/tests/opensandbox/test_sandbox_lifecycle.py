"""第一阶段：沙箱生命周期测试。"""
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.config import ConnectionConfig

from .conftest import OPENSANDBOX_IMAGE, DEFAULT_RESOURCE


pytestmark = pytest.mark.asyncio


class TestSandboxLifecycle:
    """沙箱创建、查询、续期、销毁。"""

    async def test_create_and_destroy(self, connection_config):
        """创建 python 沙箱并验证状态为 Running，然后销毁。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE,
            connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            info = await sbx.get_info()
            assert info.status.state.lower() == "running"
        finally:
            await sbx.destroy()

    async def test_create_with_timeout(self, connection_config):
        """创建带 timeout 的沙箱，验证 expires_at 非空。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE,
            connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            info = await sbx.get_info()
            assert info.expires_at is not None
        finally:
            await sbx.destroy()

    async def test_create_with_env(self, connection_config):
        """创建时注入环境变量，通过命令验证。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE,
            connection_config=connection_config,
            timeout=timedelta(minutes=5),
            env={"TEST_VAR": "hello_opensandbox"},
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            result = await sbx.commands.run("echo $TEST_VAR")
            stdout_text = "".join(m.text for m in result.logs.stdout)
            assert "hello_opensandbox" in stdout_text
        finally:
            await sbx.destroy()

    async def test_create_with_resource_limits(self, connection_config):
        """指定 CPU/内存限制创建沙箱。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE,
            connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource={"cpu": "200m", "memory": "256Mi"},
            ready_timeout=timedelta(seconds=120),
        )
        try:
            info = await sbx.get_info()
            assert info.status.state.lower() == "running"
        finally:
            await sbx.destroy()

    async def test_get_info(self, connection_config):
        """验证 get_info 返回完整沙箱信息。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE,
            connection_config=connection_config,
            timeout=timedelta(minutes=5),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            info = await sbx.get_info()
            assert info.status.state.lower() == "running"
            assert info.id == sbx.id
        finally:
            await sbx.destroy()

    async def test_renew(self, connection_config):
        """创建短 timeout 沙箱，续期后验证过期时间延长。"""
        sbx = await Sandbox.create(
            OPENSANDBOX_IMAGE,
            connection_config=connection_config,
            timeout=timedelta(minutes=2),
            resource=DEFAULT_RESOURCE,
            ready_timeout=timedelta(seconds=120),
        )
        try:
            info_before = await sbx.get_info()
            await sbx.renew(timedelta(minutes=30))
            info_after = await sbx.get_info()
            # 续期后过期时间应晚于续期前
            if info_before.expires_at and info_after.expires_at:
                assert info_after.expires_at > info_before.expires_at
        finally:
            await sbx.destroy()
