"""第二阶段：技能执行场景测试。

模拟 cia-trae-agent 中各技能的沙箱执行场景。
"""
import json

import pytest
import pytest_asyncio

from opensandbox.models.filesystem import WriteEntry


pytestmark = pytest.mark.asyncio


class TestSkillScenarios:
    """基于 cia-trae-agent 技能场景的沙箱功能验证。"""

    async def test_chart_render_scenario(self, sandbox):
        """模拟 chart_renderer：在沙箱中执行 Python 生成图表数据。"""
        script = """
import json
data = {"labels": ["Q1","Q2","Q3","Q4"], "values": [10,25,18,30]}
chart_config = {"type": "bar", "data": data, "title": "季度营收"}
print(json.dumps(chart_config, ensure_ascii=False))
"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/chart_gen.py", data=script, mode=644)
        ])
        result = await sandbox.commands.run("python3 /tmp/chart_gen.py")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        parsed = json.loads(stdout_text.strip())
        assert parsed["type"] == "bar"
        assert len(parsed["data"]["labels"]) == 4

    async def test_file_parse_scenario(self, sandbox):
        """模拟 mineru 文档解析：上传文件到沙箱 -> 沙箱内解析。"""
        # 模拟上传一个文本文件
        doc_content = "# 测试文档\n\n这是一份测试文档内容。\n包含多行文本。"
        await sandbox.files.write_files([
            WriteEntry(path="/data/session/upload/doc.md", data=doc_content, mode=644)
        ])
        # 模拟解析：读取文件并统计字数
        parse_script = (
            "import json\n"
            "with open('/data/session/upload/doc.md', 'r') as f:\n"
            "    content = f.read()\n"
            "result = {'chars': len(content), 'lines': content.count('\\n') + 1, 'preview': content[:50]}\n"
            "print(json.dumps(result, ensure_ascii=False))\n"
        )
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/parse_doc.py", data=parse_script, mode=644)
        ])
        result = await sandbox.commands.run("python3 /tmp/parse_doc.py")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        parsed = json.loads(stdout_text.strip())
        assert parsed["chars"] > 0
        assert parsed["lines"] >= 3

    async def test_data_processing_scenario(self, sandbox):
        """模拟数据处理：沙箱内执行 CSV 数据分析。"""
        csv_data = "name,amount\nAlice,100\nBob,200\nCharlie,150\n"
        await sandbox.files.write_files([
            WriteEntry(path="/data/session/data.csv", data=csv_data, mode=644)
        ])
        analysis_script = """
import csv, json
with open("/data/session/data.csv") as f:
    reader = csv.DictReader(f)
    rows = list(reader)
total = sum(int(r["amount"]) for r in rows)
result = {"count": len(rows), "total": total, "avg": total / len(rows)}
print(json.dumps(result))
"""
        await sandbox.files.write_files([
            WriteEntry(path="/tmp/analyze.py", data=analysis_script, mode=644)
        ])
        result = await sandbox.commands.run("python3 /tmp/analyze.py")
        stdout_text = "".join(m.text for m in result.logs.stdout)
        parsed = json.loads(stdout_text.strip())
        assert parsed["count"] == 3
        assert parsed["total"] == 450

    async def test_skill_directory_injection(self, sandbox):
        """验证技能目录可通过文件写入方式注入沙箱。"""
        # 模拟将技能文件写入沙箱
        skill_md = "# bocha_search\nUse this skill to search the web."
        skill_py = "def search(query): return f'results for {query}'"
        await sandbox.files.write_files([
            WriteEntry(path="/workspace/skills/bocha_search/SKILL.md", data=skill_md, mode=644),
            WriteEntry(path="/workspace/skills/bocha_search/bocha_search.py", data=skill_py, mode=644),
        ])
        # 验证技能文件存在且可执行
        cmd = "cd /workspace/skills/bocha_search && python3 -c 'from bocha_search import search; print(search(chr(116)+chr(101)+chr(115)+chr(116)))'"
        result = await sandbox.commands.run(cmd)
        stdout_text = "".join(m.text for m in result.logs.stdout)
        assert "results for test" in stdout_text
