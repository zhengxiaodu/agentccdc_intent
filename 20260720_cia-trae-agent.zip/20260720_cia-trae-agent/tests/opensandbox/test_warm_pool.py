"""预热池功能测试。

验证 OpenSandboxWorkspaceManager 的沙箱预热池：
- 启动时预创建指定数量的空闲沙箱
- 用户请求时从池中直接分配（低延迟）
- 取出后自动补充
- 关闭时池中沙箱全部销毁
"""
import asyncio
from datetime import timedelta

import pytest
import pytest_asyncio

from opensandbox import Sandbox
from opensandbox.config import ConnectionConfig

from .conftest import OPENSANDBOX_IMAGE, DEFAULT_RESOURCE

pytestmark = pytest.mark.asyncio


@pytest.fixture
def pool_manager(connection_config):
    """创建启用预热池的 WorkspaceManager（pool_size=2）。"""
    import sys
    sys.path.insert(0, ".")
    from app.services.opensandbox_workspace_manager import OpenSandboxWorkspaceManager

    mgr = OpenSandboxWorkspaceManager(
        connection_config=connection_config,
        base_image=OPENSANDBOX_IMAGE,
        basedir="/data/workspaces",
        ttl=600,
        resource=DEFAULT_RESOURCE,
        ready_timeout=timedelta(seconds=120),
        pool_size=2,
        pool_refill=True,
    )
    return mgr


class TestWarmPool:
    """预热池核心功能验证。"""

    async def test_pool_warmup(self, pool_manager):
        """启动预热后，池中有 pool_size 个空闲沙箱。"""
        await pool_manager._warm_up()
        try:
            assert len(pool_manager._warm_pool) == 2
            # 验证池中沙箱均存活
            for sbx in pool_manager._warm_pool:
                result = await sbx.commands.run("echo 1")
                assert result.exit_code == 0
        finally:
            await pool_manager._destroy_pool()

    async def test_acquire_from_pool(self, pool_manager):
        """从预热池分配沙箱后，池大小减 1。"""
        await pool_manager._warm_up()
        try:
            initial_size = len(pool_manager._warm_pool)
            sbx = await pool_manager._acquire_from_pool()
            assert sbx is not None
            assert len(pool_manager._warm_pool) == initial_size - 1
            # 验证分配到的沙箱可用
            result = await sbx.commands.run("echo hello")
            assert result.exit_code == 0
            # 清理分配出的沙箱
            await sbx.destroy()
        finally:
            await pool_manager._destroy_pool()

    async def test_pool_refill(self, pool_manager):
        """取出沙箱后，池自动补充回 pool_size。"""
        await pool_manager._warm_up()
        try:
            sbx = await pool_manager._acquire_from_pool()
            assert sbx is not None
            # 等待后台补充完成（补充需要创建沙箱，~15-30s）
            await asyncio.sleep(35)
            assert len(pool_manager._warm_pool) >= 1
            # 清理
            await sbx.destroy()
        finally:
            await pool_manager._destroy_pool()

    async def test_create_workspace_uses_pool(self, pool_manager):
        """create_workspace 优先从预热池分配。"""
        await pool_manager._warm_up()
        try:
            initial_pool = len(pool_manager._warm_pool)
            # 首次请求应从池中取
            sbx = await pool_manager.create_workspace("pool-user-1", "session-1")
            assert sbx is not None
            # 池应减少（可能已触发补充）
            assert len(pool_manager._warm_pool) < initial_pool or len(pool_manager._warm_pool) == initial_pool - 1
            # 验证沙箱可用
            result = await sbx.commands.run("echo pool_test")
            assert result.exit_code == 0
        finally:
            await pool_manager.close_all()

    async def test_pool_destroy_on_close(self, pool_manager):
        """close_all 销毁池中所有沙箱。"""
        await pool_manager._warm_up()
        assert len(pool_manager._warm_pool) == 2
        await pool_manager.close_all()
        assert len(pool_manager._warm_pool) == 0
